/* ************************************************* *
 *         Serial Peripheral Interface (SPI)         *
 *                   Library                         *
 * ************************************************* */

#ifndef _SPI_H
#define _SPI_H

#define  SPIF    0x80
#define  SPTEF   0x20
#define  MODF    0x10

#endif  /* ifndef _SPI_H */
